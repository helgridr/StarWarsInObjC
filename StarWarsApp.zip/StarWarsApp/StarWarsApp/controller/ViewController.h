//
//  ViewController.h
//  StarWarsApp
//
//  Created by Godohaldo Perez on 9/26/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "DetailViewController.h"
#import "Cache.h"
#import "Networking.h"

@interface ViewController : UITableViewController

@property NSMutableArray *testNames;

@end

