//
//  DetailViewController.m
//  StarWarsApp
//
//  Created by Godohaldo Perez on 9/26/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//


#import "DetailViewController.h"


@interface DetailViewController ()

@end

@implementation DetailViewController
@synthesize label;
@synthesize image;
@synthesize name;
@synthesize picture;


- (void)viewDidLoad {
    [super viewDidLoad];
    [label setText:name];
    UIImage *myImage = (UIImage*)[[Cache.shared imageCache] objectForKey:name];
    if (myImage != nil) {
        [self image].image = myImage;
    }
    else{
        [self image].image = [UIImage imageNamed:@"person-placeholder"];
        __weak DetailViewController *weakSelf = self;
        [Networking getImage:name andCompletionHandler:^(UIImage *image) {
            if (image != nil){
                [[Cache.shared imageCache] setObject:image forKey:weakSelf.name];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakSelf image].image = image;
                });
            }
        }];
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
