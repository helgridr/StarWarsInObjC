//
//  DetailViewController.h
//  StarWarsApp
//
//  Created by Godohaldo Perez on 9/26/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Cache.h"
#import "Networking.h"



@interface DetailViewController : UIViewController

@property (nonatomic) IBOutlet UILabel * label;
@property (nonatomic) IBOutlet UIImageView * image;

@property (nonatomic) NSString *name;
@property (nonatomic) UIImage *picture;

@end

