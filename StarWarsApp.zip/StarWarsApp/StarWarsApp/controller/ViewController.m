//
//  ViewController.m
//  StarWarsApp
//
//  Created by Godohaldo Perez on 9/26/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController

@synthesize testNames;


- (void)viewDidLoad {
    [super viewDidLoad];
    testNames = [[NSMutableArray alloc] init];
    __weak ViewController *weakSelf = self;
    [Networking callNetwork:@"https://swapi.co/api/people/" andCompletionHandler:^(NSArray *names) {
        if (names.count != 0){
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.testNames addObjectsFromArray:names];
                [weakSelf.tableView reloadData];
            });
        }
    }];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return testNames.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
    }
    NSString* name = [testNames objectAtIndex:indexPath.row];
    
    [cell textLabel].text = name;
    UIImage *myImage = (UIImage*)[[Cache.shared imageCache] objectForKey:name];
    if (myImage != nil) {
        [cell imageView].image = myImage;
    }
    else{
        [cell imageView].image = [UIImage imageNamed:@"person-placeholder"];
        __weak UITableViewCell *weakCell = cell;
        [Networking getImage:name andCompletionHandler:^(UIImage *image) {
            if (image != nil){
                [[Cache.shared imageCache] setObject:image forKey:name];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakCell imageView].image = image;
                });
            }
        }];
    }
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self performSegueWithIdentifier:@"ToDetailView" sender:self];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    NSString *identifier = segue.identifier;
    if ([identifier isEqualToString: @"ToDetailView"]){
        DetailViewController *nextView = [segue destinationViewController];
        NSIndexPath *indexPath = self.tableView.indexPathForSelectedRow;
        nextView.name = testNames[indexPath.row];
        [self.tableView deselectRowAtIndexPath:indexPath animated:true];
    }
}

@end
