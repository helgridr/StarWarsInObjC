//
//  Networking.m
//  StarWarsApp
//
//  Created by Godohaldo Perez on 9/27/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Networking.h"
@interface Networking()
@end

@implementation Networking
+ (void)callNetwork:(NSString *)url andCompletionHandler: (void(^)(NSArray* names))completion {
     NSURL * myUrl = [[NSURL alloc] initWithString:url];
     NSURLSessionTask * task = [NSURLSession.sharedSession dataTaskWithURL:myUrl completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
         NSMutableArray *nameArray = [[NSMutableArray alloc] init];
         if (error != nil){
             completion(nameArray);
             return;
         }
         if (data == nil) {
             completion(nameArray);
             return;
         }
         NSError *jsonError = nil;
     
         NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&jsonError];
         if (jsonError != nil){
             return;
         }
         NSArray *results = (NSArray *)[dictionary objectForKey:@"results"];
         //NSMutableArray *nameArray = [[NSMutableArray alloc] init];
         for (id result in results){
             [nameArray addObject:(NSString *)[(NSDictionary *)result objectForKey:@"name"]];
         }
         completion(nameArray);
         if (![[dictionary objectForKey:@"next"] isEqual:[NSNull null]]){
             NSString * newUrl = (NSString *) [dictionary objectForKey:@"next"];
             [Networking callNetwork:newUrl andCompletionHandler:completion];
         }

     }];
     [task resume];

}
+ (void)getImage:(NSString *)name andCompletionHandler: (void(^)(UIImage* image))completion {
    NSString *urlAdd = [[name stringByReplacingOccurrencesOfString:@" " withString:@""] stringByAppendingString:@".png"];
    urlAdd = [urlAdd stringByReplacingOccurrencesOfString:@"é" withString:@"e"];
    
    NSString *url = [@"https://raw.githubusercontent.com/sbassett1/swImages/master/" stringByAppendingString:urlAdd];
    
    NSURL * myUrl = [[NSURL alloc] initWithString:url];
    NSURLSessionTask * task = [NSURLSession.sharedSession dataTaskWithURL:myUrl completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error != nil){
            completion(nil);
            return;
        }
        if (data == nil) {
            completion(nil);
            return;
        }

        UIImage* image = [UIImage imageWithData:data];
        completion(image);
        
    }];
    [task resume];
    
}
@end
