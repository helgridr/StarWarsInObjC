//
//  Cache.m
//  StarWarsApp
//
//  Created by Godohaldo Perez on 9/27/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Cache.h"

//got this from http://www.galloway.me.uk/tutorials/singleton-classes/
@implementation Cache
@synthesize imageCache;

+ (id)shared{
    static Cache *sharedCache = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedCache = [[self alloc] init];
    });
    return sharedCache;
}

-(id)init{
    if (self = [super init]){
        imageCache = [[NSCache alloc] init];
    }
    return self;
}

@end
