//
//  Networking.h
//  StarWarsApp
//
//  Created by Godohaldo Perez on 9/27/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//
#import <foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Networking:NSObject

+ (void)callNetwork:(NSString *)url andCompletionHandler: (void(^)(NSArray*names))completion;
+ (void)getImage:(NSString *)name andCompletionHandler: (void(^)(UIImage* image))completion;

@end
