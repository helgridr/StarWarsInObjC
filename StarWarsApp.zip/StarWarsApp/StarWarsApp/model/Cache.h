//
//  Header.h
//  StarWarsApp
//
//  Created by Godohaldo Perez on 9/27/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

#import <foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface Cache:NSObject{
    NSCache *imageCache;
}

@property (atomic, retain) NSCache *imageCache;

+ (id)shared;

@end
